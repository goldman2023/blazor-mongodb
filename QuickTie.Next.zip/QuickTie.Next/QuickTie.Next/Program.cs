using AspNetCore.Identity.Mongo;
using Microsoft.Extensions.Options;
using QuickTie.Cloud.Repository;
using QuickTie.Data;
using QuickTie.Data.Models;
using QuickTie.Next.Data.Services;
using QuickTie.Next.Helpers.Bootstrap;
using QuickTie.Next.Helpers.Libs;
using QuickTie.Next.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

builder.Services.AddDevExpressBlazor(options =>
{
    options.BootstrapVersion = DevExpress.Blazor.BootstrapVersion.v5;
    options.SizeMode = DevExpress.Blazor.SizeMode.Medium;
});

// Mongo
builder.Services.Configure<MongoDbSettings>(builder.Configuration.GetSection("MongoDBSettings"));

builder.Services.AddSingleton<IMongoDbSettings>(serviceProvider => serviceProvider.GetRequiredService<IOptions<MongoDbSettings>>().Value);

builder.Services.AddSingleton(typeof(IMongoRepository<>), typeof(MongoRepository<>));

builder.Services.AddIdentityMongoDbProvider<QuickTieUser, QuickTieRole>(identity =>
{
    identity.Password.RequiredLength = 8;
},
mongo =>
{
    mongo.ConnectionString = builder.Configuration.GetSection("MongoDBSettings")["ConnectionString"];
    mongo.UsersCollection = "users";
    mongo.RolesCollection = "roles";
    // other options
});

builder.Services.AddSingleton<IQuickTieTheme, QuickTieTheme>();
builder.Services.AddSingleton<IBootstrapBase, BootstrapBase>();

builder.Services.AddScoped<TaskService>();
builder.WebHost.UseWebRoot("wwwroot");
builder.WebHost.UseStaticWebAssets();

IConfiguration configuration = new ConfigurationBuilder()
                            .AddJsonFile("themesettings.json")
                            .Build();

var app = builder.Build();

QuickTieThemeSettings.init(configuration);

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();