using Microsoft.AspNetCore.Identity;
using QuickTie.Cloud.Repository;
using QuickTie.Data.Models;

namespace QuickTie.Next.Data.Services
{
    public class TaskService
    {
        private readonly IMongoRepository<TaskItem> _tasksRepository;
        private readonly UserManager<QuickTieUser> _userManager;

        public TaskService(IMongoRepository<TaskItem> tasksRepository, UserManager<QuickTieUser> userManager)
        {
            _tasksRepository = tasksRepository;
            _userManager = userManager;
        }

        public async Task<IEnumerable<TaskItem>> GetAsync(string company = "")
        {

            return await _tasksRepository.GetAsync();
            //    var user = await _userManager.GetUserAsync(User);

            //    IEnumerable<TaskItem> tasks = User.IsInRole("Sales") ? await _tasksRepository.FilterByAsync(x => x.AssignedTo == user.Id) : 

            //    if (!string.IsNullOrWhiteSpace(company))
            //    {
            //        tasks = tasks.Where(x => x.AssociatedCompanyId == company);
            //    }
        }
    }
}