namespace QuickTie.Next.Helpers.Libs;

class QuickTieThemeSettings
{
    public static QuickTieThemeBase config;

    public static void init(IConfiguration configuration)
    {
        config = configuration.GetSection("Theme").Get<QuickTieThemeBase>();
    }
}
