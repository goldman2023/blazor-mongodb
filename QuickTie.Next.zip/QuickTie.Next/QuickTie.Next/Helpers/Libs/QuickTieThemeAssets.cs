namespace QuickTie.Next.Helpers.Libs;

class QuickTieThemeAssets
{
    public string Favicon { get; set; }

    public List<string> Fonts { get; set; }

    public List<string> Css { get; set; }

    public List<string> Js { get; set; }
}