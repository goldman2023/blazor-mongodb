namespace QuickTie.Next.Helpers.Libs;

public interface IQuickTieThemeHelpers
{
    void addBodyAttribute(string attribute, string value);

    void removeBodyAttribute(string attribute);

    void addBodyClass(string className);

    void removeBodyClass(string className);
}