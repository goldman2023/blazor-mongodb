using QuickTie.Next.Helpers.Libs;

namespace QuickTie.Next.Helpers.Bootstrap;

public interface IBootstrapBase
{
    void initThemeMode();
    
    void initThemeDirection();
    
    void initRtl();

    void initLayout();

    void init(IQuickTieTheme theme);
}