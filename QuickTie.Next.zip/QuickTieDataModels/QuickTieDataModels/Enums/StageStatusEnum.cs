﻿using QuickTie.Data.Attributes;
using QuickTie.Data.Models.Attributes;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models.Enums
{
    public enum StageStatus : int
    {
        [Display(Name="Created")]
        [AllowableStage(StageState.Sales)]
        Created = 0,
        [Display(Name = "Waiting On Customer")]
        [AllowableStage(StageState.Sales)]
        WaitingOnCustomer = 1,
        [Display(Name = "PO Received")]
        [AllowableStage(StageState.Sales)]
        POReceived = 2,

        [Display(Name = "Started")]
        [AllowableStage(StageState.Design)]
        Started = 3,
    }
}
