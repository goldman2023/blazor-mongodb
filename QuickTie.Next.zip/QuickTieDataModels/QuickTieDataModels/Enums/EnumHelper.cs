﻿using QuickTie.Data.Attributes;
using QuickTie.Data.Models.Attributes;
using QuickTie.Data.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace QuickTie.Data.Helpers
{
    public static class EnumHelper<T>  where T : Enum
    {
        public static IList<T> GetValues(Enum value)
        {
            var enumValues = new List<T>();

            foreach (FieldInfo fi in value.GetType().GetFields(BindingFlags.Static | BindingFlags.Public))
            {
                enumValues.Add((T)Enum.Parse(value.GetType(), fi.Name, false));
            }
            return enumValues;
        }

        public static T Parse(string value)
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }

        public static int ParseInt(string value)
        {
            return (int)Enum.Parse(typeof(T), value, true);
        }

        public static IList<string> GetNames(Enum value)
        {
            return value.GetType().GetFields(BindingFlags.Static | BindingFlags.Public).Select(fi => fi.Name).ToList();
        }

        public static IList<string> GetNames()
        {
            return typeof(T).GetFields(BindingFlags.Static | BindingFlags.Public).Select(fi => fi.Name).ToList();
        }

        public static IList<string> GetDisplayValues(Enum value)
        {
            return GetNames(value).Select(obj => GetDisplayValue(Parse(obj))).ToList();
        }

        public static IList<string> GetDisplayValues()
        {
            return GetNames().Select(obj => GetDisplayValue(Parse(obj))).ToList();
        }

        public static IList<string> GetColorValues()
        {
            return GetNames().Select(obj => GetColorValue(Parse(obj))).ToList();
        }

        public static IEnumerable<dynamic> GetDisplayValuesList()
        {
            return GetNames().Select(name => new { Value = ParseInt(name), Text = GetDisplayValue(Parse(name)), Icon = GetIconValue(Parse(name)), Html = GetHtmlValue(Parse(name)), Color = GetColorValue(Parse(name)) });
        }

        private static string lookupResource(Type resourceManagerProvider, string resourceKey)
        {
            var resourceKeyProperty = resourceManagerProvider.GetProperty(resourceKey,
                BindingFlags.Static | BindingFlags.Public, null, typeof(string),
                new Type[0], null);
            if (resourceKeyProperty != null)
            {
                return (string)resourceKeyProperty.GetMethod.Invoke(null, null);
            }

            return resourceKey; // Fallback with the key name
        }

        public static string GetDisplayValue(T value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());

            var descriptionAttributes = fieldInfo.GetCustomAttributes(
                typeof(DisplayAttribute), false) as DisplayAttribute[];

            if (descriptionAttributes[0].ResourceType != null)
                return lookupResource(descriptionAttributes[0].ResourceType, descriptionAttributes[0].Name);

            if (descriptionAttributes == null) return string.Empty;
            return (descriptionAttributes.Length > 0) ? descriptionAttributes[0].Name : value.ToString();
        }

        public static string GetColorValue(T value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());

            var descriptionAttributes = fieldInfo.GetCustomAttributes(typeof(ColorAttribute), false) as ColorAttribute[];

            if (descriptionAttributes == null) return string.Empty;
            return (descriptionAttributes.Length > 0) ? descriptionAttributes[0].Color : value.ToString();
        }

        public static string GetIconValue(T value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());
            
            var descriptionAttributes = fieldInfo.GetCustomAttributes(typeof(BootstrapIconAttribute), false) as BootstrapIconAttribute[];

            if (descriptionAttributes == null) return string.Empty;
            return (descriptionAttributes.Length > 0) ? descriptionAttributes[0].Name : value.ToString();
        }

        public static IList<T> GetAllowableStageValues(StageState stage)
        {
            var enumValues = new List<T>();

            foreach (FieldInfo fi in typeof(T).GetType().GetFields(BindingFlags.Static | BindingFlags.Public))
            {
                var attr = fi.GetCustomAttributes(typeof(AllowableStageAttribute), false) as AllowableStageAttribute[];
                if (attr == null) continue;
                if(attr.Length > 0){
                    if(attr[0].AllowableStage == stage) enumValues.Add((T)Enum.Parse(typeof(T).GetType(), fi.Name, false));
                }    
            }
            return enumValues;
        }

        public static int GetAllowableStageValue(T value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());

            var descriptionAttributes = fieldInfo.GetCustomAttributes(typeof(AllowableStageAttribute), false) as AllowableStageAttribute[];

            if (descriptionAttributes == null) return -1;
            return (descriptionAttributes.Length > 0) ? (int)descriptionAttributes[0].AllowableStage : -1;
        }

        public static string GetHtmlValue(T value)
        {
            var icon = GetIconValue(value);

            var text = GetDisplayValue(value);


            return $"<div><i class='{icon}'></i>text</div>";
        }
    }
}
