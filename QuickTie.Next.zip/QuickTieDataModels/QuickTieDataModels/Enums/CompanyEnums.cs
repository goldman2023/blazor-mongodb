﻿using QuickTie.Data.Attributes;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Enums
{
    public enum CompanyType
    {
        [BootstrapIcon("bi bi-house pe-3 text-success")]
        [Display(Name = "Builder")]
        Builder = 0,
        [BootstrapIcon("bi bi-house-fill pe-3 text-primary")]
        [Display(Name = "Single Family Builder")]
        SingleFamilyBuilder = 1,
        [BootstrapIcon("bi bi-hammer pe-3 text-primary")]
        [Display(Name = "Single Family Framer")]
        SingleFamilyFramer = 2,
        [BootstrapIcon("bi bi-bricks pe-3 text-primary")]
        [Display(Name = "Single Family Installer")]
        SingleFamilyInstaller = 3,
        [BootstrapIcon("bi bi-house-fill pe-3 text-secondary")]
        [Display(Name = "Multi-Family Builder")]
        MultiFamilyBuilder = 4,
        [BootstrapIcon("bi bi-hammer pe-3 text-secondary")]
        [Display(Name = "Multi-Family Framer")]
        MultiFamilyFramer = 5,
        [BootstrapIcon("bi bi-bricks pe-3 text-secondary")]
        [Display(Name = "Multi-Family Installer")]
        MultiFamilyInstaller = 6,
        [BootstrapIcon("bi bi-box-seam pe-3 text-primary")]
        [Display(Name = "Supplier")]
        Supplier = 7,
        [BootstrapIcon("bi bi-file-person pe-3 text-primary")]
        [Display(Name = "Engineer")]
        Engineer = 8,
    }

    public enum CompanyStatus
    {
        [BootstrapIcon("bi bi-bullseye pe-3 text-danger")]
        [Display(Name = "Targeted")]
        Targeted = 0,
        [BootstrapIcon("bi bi-person-check pe-3 text-primary")]
        [Display(Name = "Active")]
        Active = 1,
        [BootstrapIcon("bi bi-thermometer-high pe-3 text-danger")]
        [Display(Name = "Hot")]
        Hot = 2,
        [BootstrapIcon("bi bi-x-octagon pe-3 text-warning")]
        [Display(Name = "Closed")]
        Closed = 3,
        [BootstrapIcon("bi bi-clock-history pe-3")]
        [Display(Name = "Farming (Retention Growth)")]
        Farming = 4
    }
}
