﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickTie.Data.Models.Enums
{
    public enum StageState : int
    {
        Sales = 0,
        Estimating = 1,
        Design = 2,
        Manufacturing = 3,
        Shipping = 4,
        Invoicing = 5,
        Finished = 6
    }
}
