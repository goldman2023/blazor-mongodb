﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QuickTie.Data.Attributes;

namespace QuickTie.Data.Models.Enums
{
    public enum UserDashboardType : int
    {
        [BootstrapIcon("bi bi-clipboard pe-3")]
        [Display(Name = "Chief Technology Officer")]
        CTO = 0,
        [BootstrapIcon("bi bi-activity pe-3")]
        [Display(Name = "Chief Executive Officer")]
        CEO = 1,
        [BootstrapIcon("bi bi-check-circle pe-3")]
        [Display(Name = "President")]
        President = 2,
        [BootstrapIcon("bi bi-check-circle pe-3")]
        [Display(Name = "Chief Marketing Officer")]
        CMO = 3,
        [BootstrapIcon("bi bi-check-circle pe-3")]
        [Display(Name = "Sales")]
        Sales = 4
    }
}
