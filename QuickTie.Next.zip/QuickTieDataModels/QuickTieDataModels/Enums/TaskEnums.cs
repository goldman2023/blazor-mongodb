﻿using QuickTie.Data.Attributes;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Enums
{
    public enum TaskStatus : int
    {
        [BootstrapIcon("bi bi-clipboard pe-3 text-primary")]
        [Display(Name = "Created")]
        Created = 0,
        [BootstrapIcon("bi bi-activity pe-3 text-warning")]
        [Display(Name = "In Progress")]
        InProgress = 1,
        [BootstrapIcon("bi bi-check-circle pe-3 text-success")]
        [Display(Name = "Completed")]
        Completed = 2
    }

    public enum TaskType : int
    {
        [Color("#3AE52C")]
        [BootstrapIcon("bi bi-telephone-outbound pe-3 text-secondary")]
        [Display(Name = "Call")]
        Call = 0,
        [Color("#BB2CE5")]
        [BootstrapIcon("bi bi-envelope pe-3 text-primary")]
        [Display(Name = "Email")]
        Email = 1,
        [Color("#2CDFE5")]
        [BootstrapIcon("bi bi-person-check pe-3 text-success")]
        [Display(Name = "Meeting")]
        Meeting = 2,
        [Color("#E5DF2C")]
        [BootstrapIcon("bi bi-chat-dots pe-3")]
        [Display(Name = "Text Message")]
        TextMessage = 3
    }
}
