﻿using System.ComponentModel.DataAnnotations;
using QuickTie.Data.Attributes;

namespace QuickTie.Data.Enums
{
    public enum NoteType : int
    {
        [Color("#2C42E5")]
        [BootstrapIcon("bi bi-journal-text pe-3 text-success")]
        [Display(Name = "General")]
        General = 0,
        [Color("#E52CC9")]
        [BootstrapIcon("bi bi-truck pe-3 text-success")]
        [Display(Name = "Drop By Visit")]
        DropByVisit = 1,
        [Color("#BB2CE5")]
        [BootstrapIcon("bi bi-envelope pe-3 text-success")]
        [Display(Name = "Email")]
        Email = 2,
        [Color("#2CDFE5")]
        [BootstrapIcon("bi bi-person-check pe-3 text-success")]
        [Display(Name = "Meeting")]
        Meeting = 3,
        [Color("#3AE52C")]
        [BootstrapIcon("bi bi-telephone-outbound pe-3 text-success")]
        [Display(Name = "Phone Call")]
        PhoneCall = 4,
        [Color("#E5DF2C")]
        [BootstrapIcon("bi bi-chat-dots pe-3 text-success")]
        [Display(Name = "Text Message")]
        TextMessage = 5,
        [Color("#E53F2C")]
        [BootstrapIcon("bi bi-voicemail pe-3 text-success")]
        [Display(Name = "Voicemail")]
        Voicemail = 6,
    }
}
