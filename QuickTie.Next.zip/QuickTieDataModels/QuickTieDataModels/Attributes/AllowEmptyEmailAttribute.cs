﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace QuickTie.Data.Attributes
{
    public class AllowEmptyEmailAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Regex emailRegex = new Regex("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");

            if(string.IsNullOrWhiteSpace(value.ToString())) return ValidationResult.Success;

            return emailRegex.IsMatch(value.ToString()) ? ValidationResult.Success : new ValidationResult(ErrorMessage);

        }
    }
}
