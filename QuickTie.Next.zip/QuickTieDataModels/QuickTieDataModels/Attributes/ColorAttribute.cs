﻿using System;

namespace QuickTie.Data.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class ColorAttribute : Attribute
    {
        public ColorAttribute(string name)
        {
            Color = name;
        }

        public string Color { get; set; }
    }
}
