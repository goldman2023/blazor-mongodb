﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace QuickTie.Data.Attributes
{
    public class AllowEmptyPhoneAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Regex emailRegex = new(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$");

            if (string.IsNullOrWhiteSpace(value.ToString())) return ValidationResult.Success;

            return emailRegex.IsMatch(value.ToString()) ? ValidationResult.Success : new ValidationResult(ErrorMessage);

        }
    }
}
