﻿using MongoDB.Bson;
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace QuickTie.Data.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class EmptyObjectIdAttribute : ValidationAttribute
    {
        private readonly string _name = string.Empty;

        public EmptyObjectIdAttribute(string name)
        {
            _name = name;
        }

        public string GetErrorMessage() =>  $"{_name} cannot be empty.";

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                Debug.WriteLine($"Value coming for {_name} in is null.");
                return new ValidationResult(GetErrorMessage());
            }

            var id = (ObjectId)value;

            Debug.WriteLine($"Value coming in for {_name} is {id}.");

            Debug.WriteLine($"Comparison result for {_name} is {id.Equals(ObjectId.Empty)}.");

            return id.Equals(ObjectId.Empty) ? new ValidationResult(GetErrorMessage()) : ValidationResult.Success;
        }
    }
}
