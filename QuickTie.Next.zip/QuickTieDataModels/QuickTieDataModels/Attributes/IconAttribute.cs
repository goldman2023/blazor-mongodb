﻿using System;

namespace QuickTie.Data.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class BootstrapIconAttribute : Attribute
    {
        public BootstrapIconAttribute(string name)
        {
            Name = name;
        }

        public string Name { get; set; }
    }
}
