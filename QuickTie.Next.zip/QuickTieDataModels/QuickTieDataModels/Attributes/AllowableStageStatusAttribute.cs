﻿using QuickTie.Data.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickTie.Data.Models.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class AllowableStageAttribute : Attribute
    {
        public AllowableStageAttribute(StageState stage)
        {
            AllowableStage = stage;
        }

        public StageState AllowableStage { get; set; }
    }
}
