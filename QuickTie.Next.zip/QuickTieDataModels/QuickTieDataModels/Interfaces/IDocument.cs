﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{
    public interface IDocument
    {
        [BsonId]
        string Id { get; set; }

    }
}
