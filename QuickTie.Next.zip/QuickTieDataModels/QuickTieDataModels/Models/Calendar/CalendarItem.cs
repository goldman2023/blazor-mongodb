﻿using Newtonsoft.Json;

namespace QuickTie.Data.Models
{
    public class CalendarItem
    {
        [JsonProperty(PropertyName = "AppointmentId")]
        public string AppointmentId { get; set; }

        [JsonProperty(PropertyName = "Text")]
        public string Text { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "Type")] 
        public int Type { get; set; } = 0;

        [JsonProperty(PropertyName = "Description")]
        public string Description { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "StartDate")]
        public string StartDate { get; set; }

        [JsonProperty(PropertyName = "EndDate")]
        public string EndDate { get; set; }

        [JsonProperty(PropertyName = "AllDay")]
        public bool AllDay { get; set; }  = false;

        [JsonProperty(PropertyName = "RecurrenceRule")]
        public string RecurrenceRule { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "RecurrenceException")]
        public string RecurrenceException { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "Group")]
        public string Group { get; set; } = string.Empty;
    }
}
