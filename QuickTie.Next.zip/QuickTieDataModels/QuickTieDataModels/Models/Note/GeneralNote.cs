﻿using System;
using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class GeneralNote
    {
        public GeneralNote() { }

        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Display(Name = "Type")]
        public NoteType NoteType { get; set; } = NoteType.General;

        [Display(Name = "Created")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        [Display(Name = "Last Updated")]
        public DateTime LastUpdatedDate { get; set; } = DateTime.Now;

        public string Title { get; set; } = string.Empty;

        [Display(Name = "Note")]
        public string Note { get; set; } = string.Empty;

        [Display(Name = "Entered By")]
        public string EnteredBy { get; set; } = string.Empty;

        [Display(Name = "Entered By Id")]
        public ObjectId EnteredById { get; set; }

        [Display(Name = "Last Updated By")]
        public string LastUpdatedBy { get; set; } = string.Empty;

        [Display(Name = "Last Updated By Id")]
        public ObjectId LastUpdatedById { get; set; }

        public CalendarItem GetCalendarItem()
        {
            return new CalendarItem
            {
                AppointmentId = Id,
                Text = Title,
                Type = (int)NoteType,
                StartDate = CreatedDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                EndDate = CreatedDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                AllDay = true,
                Description = Note
            };
        }
    }
}
