﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace QuickTie.Data.Models
{
    public class Address
    {
        public Address() { }

        public Address(string name, string address1, string address2, string city, string state, string postalcode)
        {
            Name = name;
            Address1 = address1;
            Address2 = address2;
            City = city;
            State = state;
            PostalCode = postalcode;
        }

        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        [Display(Name = "Address")]
        public string Address1 { get; set; } = string.Empty;

        [Display(Name = "Address 2")]
        public string Address2 { get; set; } = string.Empty;

        [Required(ErrorMessage = "City is required.")]
        [Display(Name = "City")]
        public string City { get; set; }

        [Required(ErrorMessage = "State is required.")]
        [Display(Name = "State")]
        public string State { get; set; }

        [Required(ErrorMessage = "Postal Code is required.")]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Invalid Postal Code.")]
        [Display(Name ="Postal Code")]
        public string PostalCode { get; set; }

        public string Country { get; set; } = "US";

        public Coordinate Coordinate { get; set; } = new();

        public string GoogleMapsAddress
        {
            get
            {
                return $"{Address1}, {City} , {State} {PostalCode}";
            }
        }

        public bool IsValid()
        {
            return !string.IsNullOrWhiteSpace(Address1) ||
                 !string.IsNullOrWhiteSpace(City) ||
                 !string.IsNullOrWhiteSpace(State) ||
                 !string.IsNullOrWhiteSpace(PostalCode);
        }

	}

}
