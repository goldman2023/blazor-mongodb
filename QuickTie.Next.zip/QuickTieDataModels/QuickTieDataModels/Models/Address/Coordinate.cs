﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace QuickTie.Data.Models
{
    public class Coordinate
    {
        public Coordinate() { }

        public Coordinate(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }

        public double Latitude { get; set; } = -1.0;
        public double Longitude { get; set; } = -1.0;

        public bool IsValid()
        {
            return Latitude > 0 && Longitude > 0;
        }
	}
}
