﻿using System;
using AspNetCore.Identity.Mongo.Model;
using System.ComponentModel.DataAnnotations;
using QuickTie.Data.Models.Enums;

namespace QuickTie.Data.Models
{
    public class QuickTieUser: MongoUser
    {
        public byte[] Image { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid email format")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        public override string Email { get; set; }

        public UserDashboardType Dashboard { get; set; } = UserDashboardType.Sales;

        public string FullName => $"{FirstName} {LastName}";
    }
}
