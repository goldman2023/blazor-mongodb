﻿namespace QuickTie.Data.Models
{
    public enum AllowableLoadApplication
    {
        Floor = 0,
        Roof = 1,
        Bearing = 2,
        Uplift = 3,
        F1 = 4,
        F2 = 5,
        F3 = 6,
        F4 = 7
    }

    public enum WoodSpecies
    {
        SouthernYellowPine = 0,
        DouglasFir = 1,
        SPF = 2
    }

    public class AllowableLoad
    {
        public AllowableLoad()
        {

        }

        public AllowableLoadApplication Application = AllowableLoadApplication.Floor;

        public WoodSpecies Species = WoodSpecies.SouthernYellowPine;

        public double LoadDurationFactor = 1.0;
    }
}
