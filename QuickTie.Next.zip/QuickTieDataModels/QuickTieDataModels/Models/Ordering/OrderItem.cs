﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class OrderItem
    {
        public OrderItem() { }

        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string Building { get; set; } = string.Empty;

        public Product Item { get; set; } = new Hanger();

        public int Quantity { get; set; } = 1;

        public double Price { get; set; } = 0.0;

        public double Total { get; set; } = 0.0;

        public bool IsCredit { get; set; } = false;

        public string Note { get; set; } = string.Empty;
    }
}
