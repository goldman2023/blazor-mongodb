﻿using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using System.ComponentModel;
using QuickTie.Data.Attributes;
using QuickTie.Data.Models.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("orders")]
    public class Order : OrderBase
    {
        public Order() {}

        public Order(string acctId, long number) : base(acctId, number){}

        [DisplayName("Quote")]
        public long QuoteNumber { get; set; }

        [DisplayName("Stage")]
        public StageState State { get; set; } = StageState.Sales;

        [DisplayName("Status")]
        public StageStatus Status { get; set; } = StageStatus.Created;

        [DisplayName("Project")]
        public string ProjectId { get; set; } = string.Empty;

        [DisplayName("Project Manager")]
        public string ProjectManagerId { get; set; } = string.Empty;

        // Engineering Details
        [DisplayName("Wind Speed")]
        public double WindSpeed { get; set; } = 100;

        [DisplayName("Wind Exposure")]
        public string WindExposure { get; set; } = "A";

        [DisplayName("Seismic Zone")]
        public string SeismicZone { get; set; } = "Zone 0";

        [DisplayName("Seismic Category")]
        public string SeismicCategory { get; set; } = "A";

        // Shipments
        public List<Shipment> Shipments = new();

    }


}
