﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    public class Building
    {
        public Building() { }

        [BsonId]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string Name { get; set; } = string.Empty;

        public int Quantity { get; set; } = 1;

        public string Note { get; set; } = string.Empty;

        public double Area { get; set; } = 1;

    }
}
