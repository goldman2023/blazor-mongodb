﻿using QuickTie.Data.Attributes;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Enums
{
    public enum QuoteStatus : int
    {
        [Display(Name = "Created")]
        [BootstrapIcon("bi bi-asterisk pe-3")]
        Created = 0,
        [Display(Name = "Being Estimated")]
        [BootstrapIcon("bi bi-person-workspace pe-3")]
        BeingEstimated = 1,
        [Display(Name = "Sent for Authorization")]
        [BootstrapIcon("bi bi-send-check pe-3")]
        SentForAuthorization = 2,
        [Display(Name = "Authorized")]
        [BootstrapIcon("bi bi-check2-circle pe-3")]
        Authorized = 3,
        [Display(Name = "Sent to Customer")]
        [BootstrapIcon("bi bi-envelope-check pe-3")]
        SentToCustomer = 4,
        [Display(Name = "Being Revised")]
        [BootstrapIcon("bi bi-backspace-reverse pe-3")]
        Revision = 5,
        [Display(Name = "Converted")]
        [BootstrapIcon("bi bi-patch-check pe-3")]
        Converted = 6,
        [Display(Name = "Rejected")]
        [BootstrapIcon("bi bi-file-x pe-3")]
        Rejected = 7
    }

    public enum OrderStatus : int
    {
        [Display(Name = "Created")]
        Created = 0,
        [Display(Name = "Submitted")]
        Submitted = 1,
        [Display(Name = "Shipped")]
        Shipped = 2,
        [Display(Name = "Invoiced")]
        Invoiced = 3,
        [Display(Name = "Rejected")]
        Rejected = 4,
        [Display(Name = "Canceled")]
        Canceled = 5
    }

    public enum JobType : int
    {
        [Display(Name = "All Hardware")]
        AllHardware = 0,
        [Display(Name = "QuickTie System Only")]
        QuickTieSystemOnly = 1,
        [Display(Name = "QuickTie Cables Only")]
        CablesOnly = 2,
        [Display(Name = "Miscellaneous Hardware Only")]
        MiscHardwareOnly = 3,
        [Display(Name = "Podium Slab Job")]
        PodiumSlabJob = 4
    }

    public enum ConstructionType : int
    {
        [Display(Name = "Single Family")]
        SingleFamily = 0,
        [Display(Name = "Multi-Family")]
        MultiFamily = 1
    }

    public enum EstimatingType : int
    {
        [Display(Name = "Budget")]
        Budget = 0,
        [Display(Name = "Hard Number")]
        HardNumber = 1
    }

    public enum ShipmentStatus : int
    {
        [Display(Name = "Created")]
        Created = 0,
        [Display(Name = "Waiting On Material")]
        WaitingOnMaterial = 1,
        [Display(Name = "Waiting On Work Item")]
        WaitingOnWorkItem = 2,
        [Display(Name = "Shipped")]
        Shipped = 3,
    }
}
