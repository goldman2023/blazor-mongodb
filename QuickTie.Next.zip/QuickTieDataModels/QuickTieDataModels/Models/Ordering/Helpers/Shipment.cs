﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    public class Shipment
    {
        public Shipment() { }

        [BsonId]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        //[JsonConverter(typeof(JsonNullableEnumStringConverter<ShipmentStatus>))]
        public ShipmentStatus Status { get; set; } = ShipmentStatus.Created;

        public string Name { get; set; } = string.Empty;

        public List<string> Items { get; set; } = new();

        public string Note { get; set; } = string.Empty;

    }
}
