﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace QuickTie.Data.Models
{
    [BsonKnownTypes(typeof(Quote), typeof(Order))]
    [BsonIgnoreExtraElements]
    public abstract class OrderBase : Document
    {
        public OrderBase() { }

        public OrderBase(string acctId, long number)
        {
            AccountId = acctId;
            Number = number;
        }

        // General
        public long Number { get; set; } = 0;

        [Required]
        public string Name { get; set; } = string.Empty;

        // Customer Information
        [DisplayName("Note")]
        public string CustomerNote { get; set; } = string.Empty;

        [Required]
        [DisplayName("Account")]
        public string AccountId { get; set; } = string.Empty;

        [Required]
        [DisplayName("Rep")]
        public string RepId { get; set; } = string.Empty;

        // Misc
        [DisplayName("Job Type")]
        public JobType JobType { get; set; } = JobType.AllHardware;

        [DisplayName("Construction Type")]
        public ConstructionType ConstructionType { get; set; } = ConstructionType.MultiFamily;

        [DisplayName("Sealed Drawings")]
        public bool SealedDrawingsNeeded { get; set; } = false;

        // Dates
        [DisplayName("Created Date")]
        public DateTime CreatedDate { get; set; } = DateTime.Today;

        [DisplayName("Ship By Date")]
        //[JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime ShipByDate { get; set; } = DateTime.Today;

        [DisplayName("Last Updated Date")]
        public DateTime LastUpdatedDate { get; set; } = DateTime.Today;

        [DisplayName("Last Updated By")]
        public string LastUpdatedBy { get; set; } = string.Empty;

        // Project Location
        [DisplayName("Project Contact")]
        public string ProjectContact { get; set; } = string.Empty;

        [DisplayName("Project Address")]
        public string ProjectAddress { get; set; } = string.Empty;

        // Contractor
        [DisplayName("Contractor")]
        public string Contractor { get; set; } = string.Empty;

        [DisplayName("Contact")]
        public string ContractorContact { get; set; } = string.Empty;

        [DisplayName("Address")]
        public string ContractorAddress { get; set; } = string.Empty;


        [DisplayName("Mobile")]
        [AllowEmptyPhone(ErrorMessage = "Please enter a valid mobile phone number for the contractor.")]
        public string ContractorMobile { get; set; } = string.Empty;

        [DisplayName("Email")]
        [AllowEmptyEmail(ErrorMessage = "Please enter a valid email address for the contractor.")]
        public string ContractorEmail { get; set; } = string.Empty;

        // Architect
        [DisplayName("Architect")]
        public string Architect { get; set; } = string.Empty;

        [DisplayName("Contact")]
        public string ArchitectContact { get; set; } = string.Empty;

        [DisplayName("Address")]
        public string ArchitectAddress { get; set; } = string.Empty;

        [DisplayName("Mobile")]
        public string ArchitectMobile { get; set; } = string.Empty;

        [DisplayName("Email")]
        public string ArchitectEmail { get; set; } = string.Empty;

        [DisplayName("Email")]
        public string ArchitectProjectNumber { get; set; } = string.Empty;

        [DisplayName("Plan Date")]
        public DateTime ArchitectPlanDate { get; set; } = DateTime.Today;

        [DisplayName("Stage")]
        public string ArchitectPlanStage { get; set; } = string.Empty;

        // Structural Engineer
        [DisplayName("Engineer")]
        public string EngineerId { get; set; } = string.Empty;

        [DisplayName("Engineer Location")]
        public string EngineerLocationId { get; set; } = string.Empty;

        [DisplayName("Design Notes")]
        public string EngineerDesignNotes { get; set; } = string.Empty;

        [DisplayName("Mobile")]
        public string EngineerMobile { get; set; } = string.Empty;

        [DisplayName("Email")]
        public string EngineerEmail { get; set; } = string.Empty;

        [DisplayName("Project Number")]
        public string EngineerProjectNumber { get; set; } = string.Empty;

        [DisplayName("Plan Date")]
        public string EngineerPlanDate { get; set; } = string.Empty;

        [DisplayName("Revision")]
        public string EngineerLatestRevision { get; set; } = string.Empty;

        // Freight
        public double FreightCharged { get; set; } = 0.0;
        public double FreightAllocated { get; set; } = 0.0;

        // Price
        public double TotalPrice
        {
            get
            {
                return Products.Sum(x => x.Total);
            }
        }
        public bool CustomPrice { get; set; } = false;

        /// <summary>
        /// Items on the order
        /// </summary>
        public List<OrderItem> Products { get; set; } = new();

        /// <summary>
        /// Notes on the order
        /// </summary>
        public List<GeneralNote> Notes { get; set; } = new();

        /// <summary>
        /// Buildings associated with the order
        /// </summary>
        public List<Building> Buildings { get; set; } = new();

        // Calendar Item Creation
        public CalendarItem GetCalendarItem()
        {
            return new()
            {
                AppointmentId = Id,
                Text = Name,
                StartDate = ShipByDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                EndDate = ShipByDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                AllDay = true,
                Description = Number.ToString()
            };
        }

        // Methods
        public void CalculateTotalForEachOrderItem()
        {
            Products.ForEach(p =>
            {
                if (string.IsNullOrWhiteSpace(p.Building))
                {
                    p.Total = p.Price * p.Quantity;
                }
                else
                {
                    var building = Buildings.Find(s => s.Id == p.Building);
                    if (building != null)
                    {
                        p.Total = p.Price * p.Quantity * building.Quantity;
                    }
                    else
                    {
                        throw new Exception("Building was set but not found.");
                    }
                }
            }
            );
        }


    }
}
