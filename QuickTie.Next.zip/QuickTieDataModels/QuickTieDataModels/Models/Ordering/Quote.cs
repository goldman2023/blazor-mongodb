﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.ComponentModel;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("quotes")]
    public class Quote : OrderBase
    {
        public Quote() { }
        public Quote(string acctId, long number): base(acctId, number){ }

        //[JsonConverter(typeof(JsonNullableEnumStringConverter<QuoteStatus>))]
        public QuoteStatus Status { get; set; } = QuoteStatus.Created;

        [DisplayName("Estimating Type")]
       // [JsonConverter(typeof(JsonNullableEnumStringConverter<EstimatingType>))]
        public EstimatingType EstimatingType { get; set; } = EstimatingType.Budget;

        // Internal
        [DisplayName("Estimator")]
        public string TakeOffBy { get; set; } = string.Empty;

        [DisplayName("Take Off Date")]
        public DateTime TakeOffStartDate { get; set; } = DateTime.Today;

        [DisplayName("Due Date")]
        public DateTime TakeOffDueDate { get; set; } = DateTime.Today;

    }
}
