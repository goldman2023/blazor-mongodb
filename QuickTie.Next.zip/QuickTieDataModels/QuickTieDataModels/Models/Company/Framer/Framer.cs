﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonCollection("framers")]
    [BsonIgnoreExtraElements]
    public class Framer : Company
    {
        public Framer() {
            CompanyType = CompanyType.SingleFamilyFramer;
        }

    }
}
