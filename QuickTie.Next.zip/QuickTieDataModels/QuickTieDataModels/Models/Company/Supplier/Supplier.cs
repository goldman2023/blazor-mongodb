﻿using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("suppliers")]
    public class Supplier : Company
    {
        public Supplier() {
            CompanyType = CompanyType.Supplier;
        }

        public Supplier(List<string> imports)
        {
            Id = imports[0];
            Name = imports[1];

            // Address
            var cityState = imports[4].Split(",");
           
            if (cityState.Length > 1)
            {
                var statePostalCode = new List<string>( cityState[1].TrimStart(' ').Split(" "));
                if(statePostalCode.Count > 1)
                {
                    statePostalCode.RemoveAll(x => x == "");

                    MailingAddress = new Address(string.Empty, imports[2], imports[3], cityState[0], cityState[1], statePostalCode[1].Substring(0, 5) ?? "00000");
                }
            }

            // Phone
            Phone = imports[6];
            Email = imports[126];

            // Customer Type
            CompanyType = imports[127] switch
            {
                _ => CompanyType.Builder,
            };
        }

     }
}
