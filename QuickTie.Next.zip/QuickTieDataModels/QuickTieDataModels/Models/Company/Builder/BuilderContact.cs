﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public class BuilderContact : Contact
    {
        public BuilderContact(string division)
        {
            DivisionId = division;
        }
        
        [Display(Name = "Division")]
        public string DivisionId { get; set; } = string.Empty;

    }
}
