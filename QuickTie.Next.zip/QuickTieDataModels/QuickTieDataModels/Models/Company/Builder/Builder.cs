﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Attributes;
using System.Collections.Generic;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("builders")]
    public class Builder : Company
    {
        public Builder() {
            CompanyType = CompanyType.Builder;
        }

        public Builder(List<string> imports)
        {
            Id = imports[0];
            Name = imports[1];

            // Address
            var cityState = imports[4].Split(",");
           
            if (cityState.Length > 1)
            {
                var statePostalCode = new List<string>( cityState[1].TrimStart(' ').Split(" "));
                if(statePostalCode.Count > 1)
                {
                    statePostalCode.RemoveAll(x => x == "");

                    MailingAddress = new Address(string.Empty, imports[2], imports[3], cityState[0], cityState[1], statePostalCode[1].Substring(0, 5) ?? "00000");
                }
            }
        }

        public List<BuilderDivision> Divisions { get; set; } = new();

    }
}
