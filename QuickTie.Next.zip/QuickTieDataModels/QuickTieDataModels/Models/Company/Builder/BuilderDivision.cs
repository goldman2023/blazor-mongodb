﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class BuilderDivision
    {
        public BuilderDivision() { }

        public string Id { get; set; } = Guid.NewGuid().ToString() ;

        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Address information
        /// </summary>
        public Address MailingAddress { get; set; } = new Address();

        /// <summary>
        /// Contact information
        /// </summary>
        public string Email { get; set; } = string.Empty;

        public string Phone { get; set; } = string.Empty;


        // Collections
        public List<Contact> Contacts { get; set; } = new ();

        public List<GeneralNote> Notes { get; set; } = new();

        [JsonProperty(ObjectCreationHandling = ObjectCreationHandling.Replace)]
        public List<string> Engineers { get; set; } = new();

        [JsonProperty(ObjectCreationHandling = ObjectCreationHandling.Replace)]
        public List<string> Suppliers { get; set; } = new();

        [JsonProperty(ObjectCreationHandling = ObjectCreationHandling.Replace)]
        public List<string> Framers { get; set; } = new();

        [JsonProperty(ObjectCreationHandling = ObjectCreationHandling.Replace)]
        public List<string> Installers { get; set; } = new();
    }
}
