﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Attributes;
using System.Collections.Generic;
using System.ComponentModel;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("accounts")]
    public class Account : Company
    {
        public Account() { }

        public Account(List<string> imports)
        {
            Id = imports[0];
            Name = imports[1];

            // Address
            var cityState = imports[4].Split(",");
           
            if (cityState.Length > 1)
            {
                var statePostalCode = new List<string>( cityState[1].TrimStart(' ').Split(" "));
                if(statePostalCode.Count > 1)
                {
                    statePostalCode.RemoveAll(x => x == "");

                    MailingAddress = new Address(string.Empty, imports[2], imports[3], cityState[0], cityState[1], statePostalCode[1].Substring(0, 5) ?? "00000");
                }
            }

            // Phone
            Phone = imports[6];
            Email = imports[126];

            // Create Ship To Addresses

            var startingIndex = 25;

            for (int i = 0; i < 20; i++)
            {
                var address = new Address(string.Empty,imports[startingIndex], imports[startingIndex + 1], imports[startingIndex + 2], imports[startingIndex + 3], imports[startingIndex + 4]);

                if(address.IsValid()) ShippingAddresses.Add(address);
                startingIndex += 5;
            }

            // Customer Type
            switch (imports[127])
            {
                default:
                    CompanyType = CompanyType.Builder;
                    break;
            }
        }

        [DisplayName("Pricing Level")]
        //[JsonConverter(typeof(JsonNullableEnumStringConverter<PricingLevelType>))]
        public PricingLevelType PriceLevel { get; set; } = PricingLevelType.ListPrice;

        // Collections
        public List<Address> ShippingAddresses { get; set; } = new ();

   }
}
