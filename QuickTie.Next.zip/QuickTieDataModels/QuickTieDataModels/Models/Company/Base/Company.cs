﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace QuickTie.Data.Models
{
    [BsonKnownTypes(typeof(Account),
        typeof(Supplier),
        typeof(Framer),
        typeof(Builder),
        typeof(Installer))]
    [BsonIgnoreExtraElements]
    public class Company : Document
    {
        public Company() { }

        public DateTime CreatedDate { get; set; } = DateTime.Today;
        public string Name { get; set; } = string.Empty;

        public Address MailingAddress { get; set; } = new Address();

        public string Email { get; set; } = string.Empty;

        public string Phone { get; set; } = string.Empty;

        public string Fax { get; set; } = string.Empty;

        public string Note { get; set; } = string.Empty;

        public string Url { get; set; } = string.Empty;

        [Display(Name = "Type")]
        //[JsonConverter(typeof(JsonNullableEnumStringConverter<CompanyType>))]
        public CompanyType CompanyType { get; set; } = CompanyType.SingleFamilyBuilder;

        [Display(Name = "Status")]
        //[JsonConverter(typeof(JsonStringEnumConverter))]
        //[JsonConverter(typeof(JsonNullableEnumStringConverter<CompanyStatus>))]
        public CompanyStatus Status { get; set; } = CompanyStatus.Active;

        public List<Contact> Contacts { get; set; } = new();

        public List<GeneralNote> Notes { get; set; } = new();
    }
}
