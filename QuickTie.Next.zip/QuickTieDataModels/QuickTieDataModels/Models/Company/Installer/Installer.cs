﻿using MongoDB.Bson.Serialization.Attributes;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonCollection("installers")]
    [BsonIgnoreExtraElements]
    public class Installer : Company
    {
        public Installer()
        {
            CompanyType = CompanyType.SingleFamilyInstaller;
        }
    }
}
