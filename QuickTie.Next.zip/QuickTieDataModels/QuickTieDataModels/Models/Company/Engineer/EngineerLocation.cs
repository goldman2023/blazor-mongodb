﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class EngineerLocation
    {
        public EngineerLocation()  { }

        [BsonId]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Address information
        /// </summary>
        public Address MailingAddress { get; set; } = new Address();

        [Display(Name = "Address")]
        public string Address1 { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;


        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        

        [Display(Name = "Design Notes")]
        public string DesignNotes { get; set; } = string.Empty;

        // Collections
        public List<Contact> Contacts { get; set; } = new ();

        public List<GeneralNote> Notes { get; set; } = new();
    }
}
