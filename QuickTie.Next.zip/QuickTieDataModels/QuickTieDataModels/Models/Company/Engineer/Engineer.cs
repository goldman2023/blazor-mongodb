﻿using QuickTie.Data.Attributes;
using System.Collections.Generic;

namespace QuickTie.Data.Models
{
    [BsonCollection("engineers")]
    public class Engineer : Company
    {
        public Engineer() { }

        public Engineer(List<string> imports)
        {
            Name = imports[1];
        }

        public string Description { get; set; } = string.Empty;

        public List<EngineerLocation> Locations { get; set; } = new();

    }
}
