﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    [BsonCollection("tasks")]
    public class TaskItem : Document
    {
        public TaskItem() { }

        public TaskStatus Status { get; set; } = TaskStatus.Created;

        [Required]
        public TaskType Type { get; set; } = TaskType.Call;

        [Display(Name ="Created")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        
        [Display(Name = "Entered By Id")]
        public ObjectId EnteredById { get; set; }

        [Display(Name = "Due By")]
        public DateTime DueByDate { get; set; } = DateTime.Now;

        [Required]
        public string Title { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Company")]
        public string AssociatedCompanyId { get; set; }

        [Required]
        public string Note { get; set; } = string.Empty;

        public string Resolution { get; set; } = string.Empty;

        [Required]
        [EmptyObjectId("Assigned To Id")]
        [Display(Name = "Assigned To")]
        public ObjectId AssignedTo { get; set; }

        [Display(Name = "Last Updated By")]
        public string LastUpdatedBy { get; set; } = string.Empty;

        [Display(Name = "Last Updated By Id")]
        public ObjectId LastUpdatedById { get; set; }

        [Display(Name = "Last Updated")]
        public DateTime LastUpdatedDate { get; set; } = DateTime.Now;

        public HashSet<string> Tags { get; set; } = new();

        public CalendarItem GetCalendarItem()
        {
            return new()
            {
                AppointmentId = Id,
                Text = Title,
                Type = (int)Type,
                StartDate = DueByDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                EndDate = DueByDate.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                AllDay = true,
                Description = Note,
                Group = LastUpdatedBy
            };
        }
    }
}
