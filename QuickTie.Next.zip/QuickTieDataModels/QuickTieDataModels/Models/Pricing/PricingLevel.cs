﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public enum PricingLevelType
    {
        [Display(Name = "List Price")]
        ListPrice = 0,
        [Display(Name = "Pricing Level 2")]
        PricingLevel2 = 1,
        [Display(Name = "Pricing Level 3")]
        PricingLevel3 = 2,
        [Display(Name = "Pricing Level 4")]
        PricingLevel4 = 3,
        [Display(Name = "Pricing Level 5")]
        PricingLevel5 = 4,
        [Display(Name = "Retail Price")]
        RetailPrice = 5,
        [Display(Name = "Pricing Level 6")]
        PricingLevel6 = 6,
        [Display(Name = "OS Distribution")]
        OSDistPrice = 7,
        [Display(Name = "FL Distribution")]
        FLDistPrice = 8,
        [Display(Name = "Master Distribution")]
        MastDistPrice = 9,
    }
    public class PricingLevel
    {
        public PricingLevel(PricingLevelType type, double price)
        {
            Level = type;
            Price = price;
        }

        public PricingLevelType Level = PricingLevelType.ListPrice;

        public double Price = 0.0;
    }
}
