﻿using System;

namespace QuickTie.Data.Models
{
    public abstract class Document : IDocument
    {
        public Document() { }
        public string Id { get; set; } = Guid.NewGuid().ToString();

    }
}
