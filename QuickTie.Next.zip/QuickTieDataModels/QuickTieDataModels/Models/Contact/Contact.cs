﻿using System;
using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public class Contact : Document
    {
        public Contact() { }

        public string Title { get; set; } = string.Empty;

        [Required]
        [Display(Name ="First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;
        
        [DataType(DataType.PhoneNumber, ErrorMessage = "Invalid Phone Number")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Phone Number.")]
        [Display(Name = "Phone")]
        public string PhoneNumber { get; set; } = string.Empty;
        
        [DataType(DataType.PhoneNumber, ErrorMessage = "Invalid Phone Number")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Phone Number.")]
        [Display(Name = "Mobile")]
        public string MobileNumber { get; set; } = string.Empty;

        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid email format")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;
        
        public string Note { get; set; } = string.Empty;

        public string FullName => $"{FirstName} {LastName}";

    }
}
