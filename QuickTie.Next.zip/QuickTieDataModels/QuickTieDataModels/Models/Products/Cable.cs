﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Cable : Product
    {
        public Cable()
        {
            ProductType = ProductType.AircraftCable;
        }

        
        public double Length = 0;

    }
    

}
