﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class HurricaneTie : Product
    {
        public HurricaneTie()
        {
            ProductType = ProductType.Clip;
        }

        
        public double Gauge = 18;

        
        public double Width = 18;

        
        public double Height = 18;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;

        
        public double AllowableLoad = 1909;
    }
}
