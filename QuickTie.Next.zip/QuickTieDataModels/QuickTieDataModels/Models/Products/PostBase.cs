﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class PostBase : Product
    {
        public PostBase()
        {
            ProductType = ProductType.PostBase;
        }

        public Manufacturer Manufacturer = Manufacturer.QuickTie;

        
        public double Gauge = 18;

        
        public double Width = 2;

        
        public double Height = 2;

        
        public double Length = 2;

        
        public string PostSize = "4x4";

        
        public string FastenerType = "16d";

        
        public double FastenerQuantity = 12;

        
        public double BoltSize = 0.5;

        
        public double BoltQuantity = 1;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;
    }


    
}
