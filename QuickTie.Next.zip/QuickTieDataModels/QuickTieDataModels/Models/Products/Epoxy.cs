﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Epoxy : Product
    {
        public Epoxy()
        {
            ProductType = ProductType.Epoxy;
        }

        
        public double PackagingQuantity = 1;

    }
}
