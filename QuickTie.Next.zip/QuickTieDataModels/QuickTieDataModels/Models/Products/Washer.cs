﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class Washer : Product
    {
        public Washer()
        {
            ProductType = ProductType.Washer;
        }

        
        public string Coating = "Zinc";

        
        public double Width = 1;

        
        public double Length = 1;

        
        public double Thickness = 1;

        
        public double PackagingQuantity = 1;

    }
}
