﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class BearingPlate : Product
    {
        public BearingPlate()
        {
            ProductType = ProductType.BearingPlate;
        }

        
        public double Thickness = 33;


        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;

    }
}
