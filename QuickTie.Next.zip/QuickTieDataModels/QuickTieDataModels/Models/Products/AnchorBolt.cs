﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{
    [BsonIgnoreExtraElements]
    public class AnchorBolt : Product
    {
        public AnchorBolt()
        {
            ProductType = ProductType.AnchorBolt;
        }

        public double Diameter = 0.5;

        public double Length = 6;

        public string Coating = "Galvanized";

        public double PackagingQuantity = 1;
    }
}
