﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Fastener : Product
    {
        public Fastener()
        {
            ProductType = ProductType.Fastener;
        }

        
        public double Gauge = 10;

        
        public double Length = 2.5;

        
        public double ShankDiameter = 0.160;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1000;
    }
}
