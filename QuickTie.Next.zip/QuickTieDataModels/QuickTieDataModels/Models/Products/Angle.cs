﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Angle : Product
    {
        public Angle()
        {
            ProductType = ProductType.Angle;
        }

        
        public double Gauge = 18;

        
        public double Width1 = 2;

        
        public double Width2 = 2;

        
        public double Length = 2;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;
    }


    
}
