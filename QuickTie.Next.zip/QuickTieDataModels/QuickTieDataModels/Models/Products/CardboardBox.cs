﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class CardboardBox : Product
    {
        public CardboardBox()
        {
            ProductType = ProductType.CardboardBox;
        }

        
        public double Width = 1;

        
        public double Length = 1;

        
        public double Height = 1;

        
        public double PackagingQuantity = 1;

    }
}
