﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class ThreadedStud : Product
    {
        public ThreadedStud()
        {
            ProductType = ProductType.ThreadedStud;
        }

        
        public string Coating = "Galvanized";

        
        public double Length = 1;

        
        public double Diameter = 1;

        
        public double PackagingQuantity = 1;

    }
}
