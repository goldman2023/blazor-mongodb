﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class FormTie : Product
    {
        public FormTie()
        {
            ProductType = ProductType.FormTie;
        }

        
        public double FormDepth = 0;

        
        public double Gauge = 18;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;

    }
}
