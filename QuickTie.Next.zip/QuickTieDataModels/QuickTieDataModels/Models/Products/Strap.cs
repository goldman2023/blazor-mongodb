﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Strap : Product
    {
        public Strap()
        {
            ProductType = ProductType.Strap;
        }

        public Manufacturer Manufacturer = Manufacturer.QuickTie;

        
        public double Thickness = 43;

        
        public double Gauge = 18;

        
        public double Width = 18;

        
        public double Length = 12;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;
    }
}
