﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class PlywoodClip : Product
    {
        public PlywoodClip()
        {
            ProductType = ProductType.PlywoodClip;
        }

        
        public double Gauge = 20;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;
    }
}
