﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public enum ProductType: int
    {
        [Display(Name = "AirCraft Cable")]
        AircraftCable = 0,
        [Display(Name = "Hanger")]
        Hanger = 1,
        [Display(Name = "Fastener")]
        Fastener = 2,
        [Display(Name = "Epoxy")]
        Epoxy = 3,
        [Display(Name = "Plywood Clip")]
        PlywoodClip = 4,
        [Display(Name = "Angle")]
        Angle = 5,
        [Display(Name = "Strap")]
        Strap = 6,
        [Display(Name = "Clip")]
        Clip = 7,
        [Display(Name = "Coupling")]
        Coupling = 8,
        [Display(Name = "Hex Nut")]
        HexNut = 9,
        [Display(Name = "Bearing Plate")]
        BearingPlate = 10,
        [Display(Name = "Threaded Rod")]
        ThreadedRod = 11,
        [Display(Name = "Epoxy Anchor")]
        EpoxyAnchor = 12,
        [Display(Name = "Anchor Bolt")]
        AnchorBolt = 13,
        [Display(Name = "Fire Caulk")]
        FireCaulk = 14,
        [Display(Name = "Form Tie")]
        FormTie = 15,
        [Display(Name = "Post Base")]
        PostBase = 16,
        [Display(Name = "Post Cap")]
        PostCap = 17,
        [Display(Name = "Holddown")]
        Holddown = 18,
        [Display(Name = "Epoxy Accessory")]
        EpoxyAccessory = 19,
        [Display(Name = "QuickTie Cable")]
        QuickTieCable = 20,
        [Display(Name = "Washer")]
        Washer = 21,
        [Display(Name = "Threaded Stud")]
        ThreadedStud = 22,
        [Display(Name = "Cardboard Box")]
        CardboardBox = 23,
        [Display(Name = "Label")]
        Label = 24
    }
}
