﻿namespace QuickTie.Data.Models
{
    internal class AddPricing
    {
    }
}
