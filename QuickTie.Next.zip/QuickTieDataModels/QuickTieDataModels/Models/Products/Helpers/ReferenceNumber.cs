﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    
    public class ReferenceNumber
    {
        public ReferenceNumber(Manufacturer man, string name)
        {
            Manufacturer = man;
            Name = name;
        }

        public string Id { get; set; } = Guid.NewGuid().ToString();

        public Manufacturer Manufacturer { get; set; } = Manufacturer.USP;
        
        public string Name { get; set; } = string.Empty;

    }
}