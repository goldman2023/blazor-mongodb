﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public enum HangerType
    {
        [Display(Name = "Face Mount")]
        FaceMount = 0,
        [Display(Name = "Top Mount")]
        TopMount = 1,
        [Display(Name = "Inverted Flange")]
        InvertedFlange = 2
    }
}
