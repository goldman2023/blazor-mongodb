﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    public enum ImageUsage
    {
        Main = 0,
        Email = 1,
        Additional = 2
    }

    public class ProductImage 
    {
        [BsonId]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public ImageUsage Usage { get; set; } = ImageUsage.Main;

        public string Location { get; set; } = string.Empty;

    }
}
