﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    
    public class Part
    {
        public Part(Product prod, int qty)
        {
            ActualProduct = prod;
            Quantity = qty;
        }

        public string Id { get; set; } = Guid.NewGuid().ToString();

        public Product ActualProduct { get; set; }

        public int Quantity { get; set; }

    }
}