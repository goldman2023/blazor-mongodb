﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public enum QuickTieCableType
    {
        [Display(Name = "Wood")]
        Wood = 0,
        [Display(Name = "Masonry")]
        Masonry = 1
    }
}
