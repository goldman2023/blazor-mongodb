﻿using System.ComponentModel.DataAnnotations;

namespace QuickTie.Data.Models
{
    public enum Manufacturer
    {
        [Display(Name = "QuickTie")]
        QuickTie = 0,
        [Display(Name = "Mitek/USP")]
        USP = 1,
        [Display(Name = "Simpson Strong-Tie")]
        Simpson = 2
    }
}
