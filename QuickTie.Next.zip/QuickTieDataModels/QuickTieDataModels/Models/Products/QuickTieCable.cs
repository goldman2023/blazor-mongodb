﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class QuickTieCable : Product
    {
      
        public QuickTieCable()
        {
            ProductType = ProductType.QuickTieCable;
        }

        public QuickTieCable(List<string> cells, string upc, QuickTieCableType typ = QuickTieCableType.Wood)
        {
            var name = cells[1].ToUpper();
            var desc = cells[2].ToUpper();
            var salesDesc = cells[3].ToUpper();

            UPC = upc;

            Name = name;
            Description = salesDesc;

            // Cable type
            CableType = typ;

            Regex rgx = new("[^0-9.]");
            var numbers = rgx.Replace(name, "").Split(".");

            if (numbers.Length == 2)
            {
                LengthFeet = string.IsNullOrEmpty(numbers[0]) ? 0 : Convert.ToDouble(numbers[0]);
                LengthInches = string.IsNullOrEmpty(numbers[1]) ? 0 : Convert.ToDouble(numbers[1]);
            }

            // Pricing
            AddPricing(7, 17, cells);

            // Carton Quantity
            if (int.TryParse(cells[18], out int carqty))
            {
                CartonQuantity = carqty;
            }

            // Item Weight
            if (double.TryParse(cells[19], out double itemweight))
            {
                Weight = itemweight;
            }

            // Images
            switch (name.ToUpper())
            {
                // QTB
                case string when name.StartsWith("QTB"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTB.svg" });
                    break;
                // QTG
                case string when name.StartsWith("QTG"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTG.svg" });
                    break;
                // QTO
                case string when name.StartsWith("QTO"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTO.svg" });
                    break;
                // QTR
                case string when name.StartsWith("QTR"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTR.svg" });
                    break;
                // QTM.QTBM
                case string when name.StartsWith("QTM.QTBM"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTM.QTBM.svg" });
                    break;
                // QTM.QTGM
                case string when name.StartsWith("QTM.QTGM"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTM.QTGM.svg" });
                    break;
                // QTM.QTOM
                case string when name.StartsWith("QTM.QTOM"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTM.QTOM.svg" });
                    break;
                // QTM.QTRM
                case string when name.StartsWith("QTM.QTRM"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTM.QTRM.svg" });
                    break;
                default:
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/QTB.svg" });
                    break;
            }
        }

        public QuickTieCableType CableType = QuickTieCableType.Wood;

        public double LengthFeet = 0;

        public double LengthInches = 0;

        public double AllowableLoad = 1909;
        /// <summary>
        /// List of parts that make up this product.  This list will only be populated if there are subassemblies.
        /// </summary>
        public List<Part> Parts { get; set; } = new List<Part>();

        public bool Equals(QuickTieCable other)
        {
            if (other == null)
                return false;

            if (UPC == other.UPC)
                return true;
            else
                return false;
        }

        public override int GetHashCode()
        {
            return UPC.GetHashCode();
        }
    }
    

}
