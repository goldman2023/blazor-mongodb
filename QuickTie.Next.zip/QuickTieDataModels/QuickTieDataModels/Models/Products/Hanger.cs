﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace QuickTie.Data.Models
{
    
    [BsonIgnoreExtraElements]
    public class Hanger : Product
    {
        public Hanger()
        {
            ProductType = ProductType.Hanger;
        }

        public Hanger(List<string> cells)
        {
            // Get Values
            var upc = cells[0].ToUpper();
            var name = cells[1].ToUpper();
            var desc = cells[2].ToUpper();
            var salesDesc = cells[3].ToUpper();

            ProductType = ProductType.Hanger;

            UPC = string.IsNullOrWhiteSpace(upc) ? Guid.NewGuid().ToString() : upc;
            
            Name = name;

            Description = salesDesc;

            Manufacturer = name.StartsWith("USP") ? Manufacturer.USP : Manufacturer.QuickTie;

            var typeName = salesDesc.ToLower();

            // Type
            switch (typeName)
            {
                // QuickTie Hanger
                case string when typeName.Contains("inverted") || desc.ToLower().Contains("if"):
                    Type = HangerType.InvertedFlange;
                    break;
                case string when typeName.Contains("top") || desc.ToLower().Contains("top"):
                    Type = HangerType.TopMount;
                    break;
                default:
                    break;
            }

            // Joise Size
            if (desc.ToLower().IndexOf("x") > -1)
            {
                JoistSize = desc.Substring(desc.ToLower().IndexOf("x") - 1, 4).Trim();
            }

            // Gauge
            if (desc.ToLower().IndexOf("ga") > -1)
            {
                var actualIndex = desc.ToLower().IndexOf("ga") - 2 < 0 ? 0 : desc.ToLower().IndexOf("ga") - 2;
                var actualLength = desc.ToLower().IndexOf("ga") - 2 < 0 ? 1 : 2;
                if(double.TryParse(desc.Substring(actualIndex, actualLength).Trim(), out double ga))
                {
                    Gauge = ga;
                }
            }

            // Pricing
            AddPricing(7, 17, cells);

            // Carton Quantity
            if (int.TryParse(cells[18], out int carqty))
            {
                CartonQuantity = carqty;
            }

            // Item Weight
            if (double.TryParse(cells[19], out double itemweight))
            {
                Weight = itemweight;
            }

            // Reference Numbers
            var index = salesDesc.ToLower().IndexOf("ref#");
            if (index > 0)
            {
                var refnum = salesDesc.Substring(index + 4, salesDesc.Length - (index + 4) - 1);
                foreach (var item in refnum.Split(','))
                {
                    ReferenceNumbers.Add(new ReferenceNumber(Manufacturer.Simpson, item.Trim()));
                }
            }

            // Images
            switch (name)
            {
                case string when name.ToLower().StartsWith("uh.uh-if"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UH-IF.svg" });
                    break;
                case string when name.ToLower().StartsWith("uh.uh"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UH.svg" });
                    break;
                case string when name.ToLower().StartsWith("uh.ul"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UL.svg" });
                    break;
                case string when name.ToLower().StartsWith("uh.ul-if"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UL-IF.svg" });
                    break;
                case string when name.ToLower().StartsWith("uh.ulp-if"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/ULP-IF.svg" });
                    break;
                case string when name.ToLower().StartsWith("uh.um"):
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UM.svg" });
                    break;
                default:
                    Images.Add(new ProductImage() { Usage = ImageUsage.Main, Location = "https://quicktie.s3.amazonaws.com/products/images/generic/UL.svg" });
                    break;
            }
        }

        public HangerType Type = HangerType.FaceMount;

        public Manufacturer Manufacturer = Manufacturer.QuickTie;

        
        public string JoistSize = "2x4";

        
        public double Gauge = 18;

        
        public double Width = 18;

        
        public double Height = 18;

        
        public double B = 18;

        /// <summary>
        /// String containing coating information
        /// </summary>
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;

        /// <summary>
        /// Allowable loads for the hanger
        /// </summary>
        
        public List<AllowableLoad> AllowableLoads = new();

        
        public List<FastenerConfiguration> Fasteners = new();
    }

}
