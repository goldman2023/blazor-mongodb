﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;
using QuickTie.Data.Attributes;
using QuickTie.Data.Enums;

namespace QuickTie.Data.Models
{
    [BsonKnownTypes(typeof(AnchorBolt),
        typeof(Angle),
        typeof(BearingPlate),
        typeof(Cable),
        typeof(CardboardBox),
        typeof(Caulk),
        typeof(Coupling),
        typeof(Epoxy),
        typeof(Fastener),
        typeof(FormTie),
        typeof(Hanger),
        typeof(HexNut),
        typeof(HurricaneTie),
        typeof(Label),
        typeof(PlywoodClip),
        typeof(PostBase),
        typeof(PostCap),
        typeof(QuickTieCable),
        typeof(Strap),
        typeof(ThreadedRod),
        typeof(ThreadedStud),
        typeof(Washer))]
    [BsonIgnoreExtraElements]
    [BsonCollection("products")]
    public abstract class Product :Document
    {
        [JsonConstructor]
        public Product() { }

        [Display(Name= "UPC")]
        public string UPC { get; set; } = Guid.NewGuid().ToString();

        public string OldUPC { get; set; } = string.Empty;

        [Display(Name = "Name")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Desc")]
        public string Description { get; set; } = string.Empty;

        [Display(Name="Product Type")]
        public ProductType ProductType { get; set; } = ProductType.QuickTieCable;

        [Display(Name = "Cost")]
        public double UnitCost { get; set; } = 999.99;

        public double Weight { get; set; } = 999.99;

        [Display(Name = "Carton Quantity")]
        public double CartonQuantity { get; set; } = 1.0;

        public bool Obsolete { get; set; } = false;

        public bool CustomerFacing { get; set; } = true;

        // Collections
        public List<ProductImage> Images { get; set; } = new();

        public List<PricingLevel> Prices { get; set; } = new();

        public List<ReferenceNumber> ReferenceNumbers { get; set; } = new();

        // Methods
        public string MainProductImage
        {
            get
            {
                if (Images.Any(x => x.Usage == ImageUsage.Main)) return Images.First(x => x.Usage == ImageUsage.Main).Location;
                return "https://quicktie.s3.amazonaws.com/products/images/generic/noimage.png";
            }
        }

        protected void AddPricing(int start, int end, List<string> cells)
        {
            // Pricing
            for (int i = start; i < end; i++)
            {
                if (double.TryParse(cells[i], out double price))
                {
                    Prices.Add(new PricingLevel((PricingLevelType)(i - 7), Math.Round(price, 2)));
                    if (i == end - 1)
                    {
                        UnitCost = Math.Round(price, 2);
                    }
                }
            }
        }
    }

    public class ProductEqualityComparer<T> : IEqualityComparer<T> where T : class
    {
        public bool Equals(T x, T y)
        {
            if (y == null && x == null)
            {
                return true;
            }
            if (y == null || x == null)
            {
                return false;
            }
            if (x is Product && y is Product)
            {
                return ((Product)(object)x).UPC == ((Product)(object)y).UPC;
            }
            //for next class add comparing logic here
            return false;
        }

        public int GetHashCode(T prod)
        {
            if (prod is QuickTieCable)
            {
                return ((QuickTieCable)(object)prod).UPC.GetHashCode();
            }
            return 0;
        }
    }











}
