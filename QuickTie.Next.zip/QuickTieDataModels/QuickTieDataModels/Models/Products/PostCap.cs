﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class PostCap : Product
    {
        public PostCap()
        {
            ProductType = ProductType.PostCap;
        }

        public Manufacturer Manufacturer = Manufacturer.QuickTie;

        
        public double Gauge = 18;

        
        public double Width1 = 2;

        
        public double Width2 = 2;

        
        public double Height = 2;

        
        public double Length1 = 2;

        
        public double Length2 = 2;

        
        public string BeamFasteners = "16d";

        
        public double BeamFastenerQuantity = 12;

        
        public string PostFasteners = "16d";

        
        public double PostFastenerQuantity = 12;

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;
    }


    
}
