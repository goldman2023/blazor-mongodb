﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class ThreadedRod : Product
    {
        public ThreadedRod()
        {
            ProductType = ProductType.ThreadedRod;
        }

        
        public string Coating = "Galvanized";

        
        public double Length = 1;

        
        public double Diameter = 1;

        
        public double PackagingQuantity = 1;

    }
}
