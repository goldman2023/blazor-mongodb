﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class HexNut : Product
    {
        public HexNut() : base()
        {
            ProductType = ProductType.HexNut;
        }

        
        public string Coating = "Galvanized";

        
        public string MaterialGrade = "Grade 2";

        
        public double Size = 0.5;

        
        public double PackagingQuantity = 1;

    }
}
