﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Label : Product
    {
        public Label()
        {
            ProductType = ProductType.Label;
        }

        
        public string Decription = "Label";

    }
}
