﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Caulk : Product
    {
        public Caulk()
        {
            ProductType = ProductType.Angle;
        }

        
        public double Volume = 18;

        
        public double PackagingQuantity = 1;
    
    }
}
