﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class FastenerConfiguration
    {
        public FastenerConfiguration()
        {

        }

        public FastenerLocation Location = FastenerLocation.Joist;

        public int Quantity = 1;

        public Fastener Fastener = new Fastener();
    }

    public enum FastenerLocation
    {
        Joist = 0,
        Header = 1
    }
}
