﻿using MongoDB.Bson.Serialization.Attributes;

namespace QuickTie.Data.Models
{

    
    [BsonIgnoreExtraElements]
    public class Coupling : Product
    {
        public Coupling()
        {
            ProductType = ProductType.Coupling;
        }

        
        public string Coating = "Galvanized";

        
        public double PackagingQuantity = 1;

    }
}
