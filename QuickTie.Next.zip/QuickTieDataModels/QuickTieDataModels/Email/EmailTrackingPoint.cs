﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace QuickTie.Data.Models
{
    public class EmailTrackingPoint
    {
        public EmailTrackingPoint() { }

        [BsonElement]
        public string Event { get; set; } = "Prepared Email";

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string OrderNumber { get; set; } = string.Empty;

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string Account { get; set; } = string.Empty;

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string Email { get; set; } = string.Empty;

        [BsonElement]
        [BsonDefaultValue("Customer")]
        [BsonRepresentation(BsonType.String)]
        public EmailType Type { get; set; } = EmailType.Customer;

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string Status { get; set; } = "Created";

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string Error { get; set; } = string.Empty;

        [BsonElement]
        [BsonDefaultValue("")]
        [BsonIgnoreIfDefault]
        public string Reason { get; set; } = string.Empty;

        [BsonElement]
        public DateTime LastUpdated { get; set; } = DateTime.Now;
    }
}
