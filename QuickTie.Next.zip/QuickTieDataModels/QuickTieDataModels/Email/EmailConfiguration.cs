﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace QuickTie.Data.Models
{
    public enum EmailType
    {
        Rep = 0,
        Customer = 1,
        Fixed = 2
    }

    [BsonIgnoreExtraElements]
    public class EmailConfiguration
    {
        public EmailConfiguration() { }

        [BsonElement]
        [BsonRepresentation(BsonType.String)]
        [BsonDefaultValue(2)]
        public EmailType Type { get; set; } = EmailType.Fixed;

        private string toaddress = "twalls@quicktieproducts.com";
        [BsonElement]
        public string ToAddress
        {
            get
            {
                switch (Type)
                {
                    default:
                        return toaddress;
                }
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    toaddress = value;
                }
            }
        }

        [BsonElement]
        public string FromAddress { get; set; } = "support@quicktieproducts.com";

        [BsonElement]
        public string ReplyToAddress { get; set; } = "support@quicktieproducts.com";

        [BsonElement]
        public HashSet<string> BCCAddresses { get; set; } = new HashSet<string>();

        [BsonElement]
        [BsonDefaultValue("en-US")]
        public string LanguageIdentifier { get; set; } = "en-US";

        [BsonElement]
        public string SubjectTemplate { get; set; } = string.Empty;

        public OrderBase AssociatedOrder { get; set; }

        //These fields are completed at the time of sending the email
        public string Subject { get; set; } = "No subject set";

        public string HTMLBody { get; set; } = string.Empty;
    }
}