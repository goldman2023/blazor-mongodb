﻿using QuickTie.Data.Attributes;

namespace QuickTie.Data.Models
{
    [BsonCollection("counters")]
    public class Counter
    {
        public string Id { get; set; } = "1";
        public long Value { get; set; }
    }
}
