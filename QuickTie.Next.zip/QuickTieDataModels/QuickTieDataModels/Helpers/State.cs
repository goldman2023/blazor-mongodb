﻿namespace QuickTie.Data.Models
{
    public class State
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
