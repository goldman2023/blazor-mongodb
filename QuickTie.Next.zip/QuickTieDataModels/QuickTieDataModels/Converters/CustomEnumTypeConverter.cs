﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace QuickTie.Data.Models
{
    public class JsonNullableEnumStringConverter<TEnum> : JsonConverter<TEnum>
    {
        private readonly Type _enumType;

        public JsonNullableEnumStringConverter()
        {
            // cache the underlying type
            _enumType =  typeof(TEnum);
        }

        public override TEnum Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            var value = reader.GetString();

            if (string.IsNullOrEmpty(value))
                return default; 
            else if (string.IsNullOrEmpty(value))
                throw new InvalidEnumArgumentException(
                    $"A value must be provided for enum property of type {typeof(TEnum).FullName}");
           
            // Check display name first
            foreach (var enumValue in Enum.GetValues(typeof(TEnum)))
            {
                var fi = typeof(TEnum).GetField(enumValue.ToString());

                var attributes = (DisplayAttribute[])fi.GetCustomAttributes(typeof(DisplayAttribute), false);

                if (attributes.Select(x => x.Name).ToList().Contains(value))
                {
                    return (TEnum)enumValue;
                }
            }

            if (!Enum.TryParse(_enumType, value, false, out var result) && !Enum.TryParse(_enumType, value, true, out result))
            {
                throw new JsonException(
                    $"Unable to convert \"{value}\" to Enum \"{_enumType}\".");
            }

            return (TEnum)result;
        }

        public override void Write(Utf8JsonWriter writer, TEnum value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue((int)(object)value);
        }
    }
}
