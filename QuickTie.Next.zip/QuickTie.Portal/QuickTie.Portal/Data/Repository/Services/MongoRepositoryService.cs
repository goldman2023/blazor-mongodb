﻿using Microsoft.Extensions.Caching.Memory;
using MongoDB.Driver;
using QuickTie.Cloud.Repository;
using QuickTie.Data;
using QuickTie.Data.Attributes;
using QuickTie.Data.Models;
using System.Linq.Expressions;

namespace QuickTie.Portal.Data.Repository.Services
{
    public class MongoRepository<TDocument> : IMongoRepository<TDocument> where TDocument : IDocument
    {
        private readonly IMemoryCache _cache;
        private readonly IMongoClient _client;
        private readonly IMongoCollection<TDocument> _collection;
        private readonly IMongoCollection<Counter> _counterCollection;
        private readonly string _cacheName;

        public MongoRepository(IMongoDbSettings settings, IMemoryCache cache)
        {
            _client = new MongoClient(settings.ConnectionString);

            var database = _client.GetDatabase(settings.DatabaseName);
            _collection = database.GetCollection<TDocument>(GetCollectionName(typeof(TDocument)));
            _counterCollection = database.GetCollection<Counter>(GetCollectionName(typeof(Counter)));

            _cache = cache;
            _cacheName = _collection.CollectionNamespace.CollectionName;
        }

        private string GetCollectionName(Type documentType) => ((BsonCollectionAttribute)documentType.GetCustomAttributes(
                    typeof(BsonCollectionAttribute),
                    true)
                .FirstOrDefault())?.CollectionName;

        public virtual async Task<IEnumerable<TDocument>> FilterByAsync(Func<TDocument, bool> filterExpression)
        {
            var allAccounts = await GetAsync();

            return allAccounts.Where(filterExpression);
        }

        public virtual async Task<IEnumerable<TDocument>> FilterByAsync(Func<TDocument, bool> filterExpression, Func<TDocument, string> orderbyExpression)
        {
            var allAccounts = await GetAsync();

            return allAccounts.Where(filterExpression).OrderBy(orderbyExpression);
        }

        public virtual async Task<IEnumerable<TDocument>> GetAsync(int skip = 0, int take = 0)
        {
            var cacheEntry = await _cache.GetOrCreateAsync($"all_{_cacheName}_{skip}_{take}", async entry =>
            {
                entry.AbsoluteExpiration = new DateTimeOffset(DateTime.Now.AddMinutes(15));
                return await _collection.Find(x => true)
                                    .Skip(skip)
                                    .Limit(take)
                                    .ToListAsync();
            });
            return cacheEntry;
        }
        public virtual async Task<long> GetCountAsync()
        {
            return await _collection.CountDocumentsAsync(Builders<TDocument>.Filter.Empty);
        }

        public virtual Task<TDocument> FindOneAsync(Expression<Func<TDocument, bool>> filterExpression)
        {
            return Task.Run(() => _collection.Find(filterExpression).FirstOrDefaultAsync());
        }

        public virtual async Task<TDocument> FindByIdAsync(string id)
        {
            var cacheEntry = await _cache.GetOrCreateAsync($"{_cacheName}_{id}", async entry =>
            {
                entry.AbsoluteExpiration = new DateTimeOffset(DateTime.Now.AddMinutes(15));
                return await _collection.Find(doc => doc.Id == id).SingleOrDefaultAsync();
            });

            return cacheEntry;
        }

        public virtual async Task InsertOneAsync(TDocument document)
        {
            _cache.Set($"{_cacheName}_{document.Id}", document);
            _cache.Remove($"all_{_cacheName}");
            await _collection.InsertOneAsync(document);
        }

        public virtual async Task<bool> ReplaceOneAsync(TDocument document)
        {
            var filter = Builders<TDocument>.Filter.Eq(doc => doc.Id, document.Id);
            var result = await _collection.ReplaceOneAsync(filter, document);

            if (result.IsAcknowledged)
            {
                _cache.Set($"{_cacheName}_{document.Id}", document);
                _cache.Remove($"all_{_cacheName}");
                return true;
            }
            return false;
        }

        public virtual async Task<TDocument> GetNextNumberAndInsert(string accountId, string sequenceType, Func<long, TDocument> Create)
        {
            // Create a session object that is used when leveraging transactions
            using (var session = await _client.StartSessionAsync())
            {
                // Begin transaction
                session.StartTransaction();

                try
                {
                    var result = await _counterCollection.FindOneAndUpdateAsync(
                        Builders<Counter>.Filter.Where(rec => rec.Id == sequenceType),
                        Builders<Counter>.Update.Inc(rec => rec.Value, 1),
                        options: new FindOneAndUpdateOptions<Counter>
                        {
                            ReturnDocument = ReturnDocument.After,
                            IsUpsert = true
                        }
                    );

                    var newObject = Create(result.Value);

                    await _collection.InsertOneAsync(newObject);

                    // Made it here without error? Let's commit the transaction
                    await session.CommitTransactionAsync();

                    _cache.Set($"{_cacheName}_{newObject.Id}", newObject);
                    _cache.Remove($"all_{_cacheName}");

                    return newObject;
                }
                catch (Exception ex)
                {
                    await session.AbortTransactionAsync();
                    throw new Exception(ex.Message);
                    ;
                }
            }
        }

        public virtual async Task<bool> DeleteOneAsync(Expression<Func<TDocument, bool>> filterExpression)
        {
            _cache.Remove($"all_{_cacheName}");
            var result = await _collection.DeleteOneAsync(filterExpression);

            if (result.IsAcknowledged) return true;

            return false;
        }
    }
}
