﻿using Microsoft.AspNetCore.Identity;
using QuickTie.Cloud.Repository;
using QuickTie.Data.Models;
using QuickTie.Portal.Data.Repository.Interface;

namespace QuickTie.Portal.Data.Repository.Services
{
    public class ProductService : IProduct
    {
        private readonly IMongoRepository<Product> _productsRepository;
        private readonly UserManager<QuickTieUser> _userManager;

        public ProductService(IMongoRepository<Product> productsRepository, UserManager<QuickTieUser> userManager)
        {
            _productsRepository = productsRepository;
            _userManager = userManager;
        }

        public async Task<IEnumerable<Product>> GetProductsAsync(int skip, int take)
        {
            return await _productsRepository.GetAsync(skip, take);
        }
        public async Task<long> GetProductsCountAsync()
        {
            return await _productsRepository.GetCountAsync();
        }
        public async Task<IEnumerable<ProductType>> GetCategoryAsync()
        {
            return await Task.Run(() => Enum.GetValues(typeof(ProductType)).Cast<ProductType>());
        }
    }
}