﻿using QuickTie.Data.Models;

namespace QuickTie.Portal.Data.Repository.Interface
{
    public interface IProduct
    {
        Task<IEnumerable<Product>> GetProductsAsync(int skip, int take);
        Task<long> GetProductsCountAsync();
        Task<IEnumerable<ProductType>> GetCategoryAsync();
    }
}
