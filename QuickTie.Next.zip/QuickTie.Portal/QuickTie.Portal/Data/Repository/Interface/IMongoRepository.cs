﻿using QuickTie.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace QuickTie.Cloud.Repository
{

    public interface IMongoRepository<TDocument> where TDocument : IDocument
    {

        Task<IEnumerable<TDocument>> FilterByAsync(Func<TDocument, bool> filterExpression);

        Task<IEnumerable<TDocument>> FilterByAsync(Func<TDocument, bool> filterExpression, Func<TDocument, string> orderbyExpression);

        //IEnumerable<TProjected> FilterBy<TProjected>(
        //    Expression<Func<TDocument, bool>> filterExpression,
        //    Expression<Func<TDocument, TProjected>> projectionExpression);

        Task<IEnumerable<TDocument>> GetAsync(int skip, int take);

        Task<long> GetCountAsync();

        Task<TDocument> FindOneAsync(Expression<Func<TDocument, bool>> filterExpression);

        Task<TDocument> FindByIdAsync(string id);

        Task InsertOneAsync(TDocument document);

        //void InsertMany(ICollection<TDocument> documents);

        //Task InsertManyAsync(ICollection<TDocument> documents);

        //void ReplaceOne(TDocument document);

        Task<bool> ReplaceOneAsync(TDocument document);

        //void DeleteOne(Expression<Func<TDocument, bool>> filterExpression);

        Task<bool> DeleteOneAsync(Expression<Func<TDocument, bool>> filterExpression);

        //void DeleteById(string id);

        //Task DeleteByIdAsync(string id);

        //void DeleteMany(Expression<Func<TDocument, bool>> filterExpression);

        //Task DeleteManyAsync(Expression<Func<TDocument, bool>> filterExpression);

        Task<TDocument> GetNextNumberAndInsert(string accountId, string sequenceType, Func<long, TDocument> Create);
    }
}
