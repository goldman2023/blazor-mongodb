﻿using QuickTie.Data.Models;

namespace QuickTie.Portal.Models
{
    public class FilterParameter
    {
        public float Start { get; set; }
        public float End { get; set; }
        public List<ProductType>? SelectedCategory { get; set; }
    }
}
